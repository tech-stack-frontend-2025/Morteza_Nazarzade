import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const Gallery = () => {
  const [ref, inView] = useInView({
    threshold: 0.1,
    triggerOnce: true,
  });

  const partners = [
    { name: 'Adobe', logo: 'Adobe' },
    { name: 'Figma', logo: 'Figma' },
    { name: 'Webflow', logo: 'Webflow' },
    { name: 'Sketch', logo: 'Sketch' },
    { name: 'Behance', logo: 'Behance' },
    { name: 'Dribbble', logo: 'Dribbble' },
  ];

  return (
    <section id="gallery" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Trusted by
            <span className="block text-purple-600">Industry Leaders</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Partnering with the world's most innovative design tools and platforms
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="relative overflow-hidden"
        >
          <div className="flex space-x-16 animate-scroll">
            {[...partners, ...partners].map((partner, index) => (
              <motion.div
                key={`${partner.name}-${index}`}
                whileHover={{ scale: 1.1 }}
                className="flex-shrink-0 w-32 h-20 bg-gray-100 rounded-lg flex items-center justify-center hover:bg-gray-200 transition-colors duration-300"
              >
                <span className="text-gray-700 font-bold text-lg">{partner.logo}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Testimonials */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mt-20"
        >
          {[
            {
              quote: "MyAwards has been instrumental in recognizing our creative work and connecting us with a global design community.",
              author: "Sarah Johnson",
              title: "Creative Director, Studio Alpha"
            },
            {
              quote: "The platform sets the gold standard for design recognition. Being featured here opened doors we never imagined.",
              author: "Marcus Chen",
              title: "Founder, Design Co."
            },
            {
              quote: "MyAwards doesn't just celebrate good design—it elevates the entire industry by showcasing what's possible.",
              author: "Elena Rodriguez",
              title: "Lead Designer, Verde Studio"
            }
          ].map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.7 + index * 0.1 }}
              className="bg-gray-50 p-8 rounded-2xl hover:shadow-lg transition-shadow duration-300"
            >
              <p className="text-gray-700 mb-6 italic">"{testimonial.quote}"</p>
              <div>
                <div className="font-semibold text-gray-900">{testimonial.author}</div>
                <div className="text-gray-600 text-sm">{testimonial.title}</div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Gallery;