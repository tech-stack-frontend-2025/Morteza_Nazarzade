import React, { useState } from 'react';
import { User, ChevronDown, Calendar, Clock } from 'lucide-react';

export const ProfileCalendar = () => {
  const [userLevel, setUserLevel] = useState('Intermediate');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  
  const levels = ['Beginner', 'Intermediate', 'Advanced'];
  
  const upcomingActivities = [
    {
      title: 'Meditation & Breathing',
      time: '9:00 AM',
      duration: '30 min',
      color: 'bg-emerald-400'
    },
    {
      title: 'Audio Reading',
      time: '2:00 PM',
      duration: '45 min',
      color: 'bg-green-400'
    },
    {
      title: 'Workout Session',
      time: '6:00 PM',
      duration: '60 min',
      color: 'bg-teal-400'
    }
  ];

  const dailyQuote = "The journey of a thousand miles begins with one step. Take care of your mind and body today.";

  return (
    <section className="py-16 px-4 bg-white">
      <div className="container mx-auto max-w-6xl">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Profile Section */}
          <div className="space-y-6">
            {/* Profile Card */}
            <div className="bg-emerald-50 border-2 border-emerald-200 rounded-2xl p-6">
              <div className="flex items-center mb-6">
                <div className="w-16 h-16 bg-emerald-300 rounded-full flex items-center justify-center mr-4">
                  <User className="h-8 w-8 text-emerald-700" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-emerald-900">Welcome Back!</h3>
                  <p className="text-emerald-700">Ready for today's wellness journey?</p>
                </div>
              </div>
              
              {/* User Level Dropdown */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-emerald-800 mb-2">
                  Your Level
                </label>
                <div className="relative">
                  <button
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                    className="w-full bg-white border-2 border-emerald-300 rounded-lg px-4 py-3 flex items-center justify-between text-left font-medium text-emerald-800 hover:border-emerald-400 transition-colors duration-200"
                  >
                    {userLevel}
                    <ChevronDown className="h-5 w-5" />
                  </button>
                  
                  {isDropdownOpen && (
                    <div className="absolute top-full left-0 right-0 bg-white border-2 border-emerald-300 rounded-lg mt-1 shadow-lg z-10">
                      {levels.map((level) => (
                        <button
                          key={level}
                          onClick={() => {
                            setUserLevel(level);
                            setIsDropdownOpen(false);
                          }}
                          className="w-full px-4 py-3 text-left hover:bg-emerald-50 transition-colors duration-200 text-emerald-800"
                        >
                          {level}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              
              {/* Current Course */}
              <div>
                <h4 className="font-medium text-emerald-800 mb-2">Current Course</h4>
                <div className="bg-white rounded-lg p-4 border border-emerald-200">
                  <p className="font-medium text-emerald-900">Mindful Living Fundamentals</p>
                  <p className="text-sm text-emerald-700 flex items-center mt-1">
                    <Clock className="h-4 w-4 mr-1" />
                    45 minutes remaining
                  </p>
                </div>
              </div>
            </div>

            {/* Daily Quote */}
            <div className="bg-green-50 border-2 border-green-200 rounded-2xl p-6">
              <h4 className="font-semibold text-green-800 mb-3">Daily Inspiration</h4>
              <blockquote className="text-green-700 italic leading-relaxed">
                "{dailyQuote}"
              </blockquote>
            </div>
          </div>

          {/* Calendar Section */}
          <div className="bg-teal-50 border-2 border-teal-200 rounded-2xl p-6">
            <div className="flex items-center mb-6">
              <Calendar className="h-6 w-6 text-teal-600 mr-3" />
              <h3 className="text-xl font-semibold text-teal-900">Today's Schedule</h3>
            </div>
            
            <div className="space-y-4">
              {upcomingActivities.map((activity, index) => (
                <div
                  key={index}
                  className="bg-white rounded-lg p-4 border border-teal-200 transition-all duration-200 hover:shadow-md hover:border-teal-300"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className={`w-4 h-4 ${activity.color} rounded-full mr-3`} />
                      <div>
                        <p className="font-medium text-teal-900">{activity.title}</p>
                        <p className="text-sm text-teal-600 flex items-center mt-1">
                          <Clock className="h-3 w-3 mr-1" />
                          {activity.duration}
                        </p>
                      </div>
                    </div>
                    <span className="text-teal-700 font-medium">{activity.time}</span>
                  </div>
                </div>
              ))}
            </div>
            
            <button className="w-full mt-6 bg-teal-500 hover:bg-teal-600 text-white py-3 rounded-lg font-medium transition-colors duration-200">
              View Full Calendar
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};