import React from 'react';
import { Leaf, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

export const Footer = () => {
  const quickLinks = [
    { name: 'About Us', href: '#about' },
    { name: 'Programs', href: '#programs' },
    { name: 'Contact', href: '#contact' },
    { name: 'Privacy Policy', href: '#privacy' }
  ];

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Youtube, href: '#', label: 'YouTube' }
  ];

  return (
    <footer className="bg-emerald-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          {/* Logo and Description */}
          <div className="md:col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <Leaf className="h-8 w-8 text-emerald-300" />
              <span className="text-2xl font-bold">Evergreen</span>
            </div>
            <p className="text-emerald-200 leading-relaxed">
              Your personal space for health, mindfulness, and growth. 
              Join our community and discover a healthier, happier you.
            </p>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-1">
            <h4 className="text-xl font-semibold mb-4 text-emerald-300">Quick Links</h4>
            <ul className="space-y-2">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    className="text-emerald-200 hover:text-emerald-300 transition-colors duration-200 font-medium"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Social Media */}
          <div className="md:col-span-1">
            <h4 className="text-xl font-semibold mb-4 text-emerald-300">Connect With Us</h4>
            <div className="flex space-x-4 mb-4">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  aria-label={social.label}
                  className="w-10 h-10 bg-emerald-700 hover:bg-emerald-600 rounded-full flex items-center justify-center transition-all duration-200 transform hover:scale-110"
                >
                  <social.icon className="h-5 w-5 text-emerald-200" />
                </a>
              ))}
            </div>
            <p className="text-emerald-200 text-sm">
              Follow us for daily wellness tips and inspiration
            </p>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-emerald-700 pt-8 text-center">
          <p className="text-emerald-300 text-sm">
            © Evergreen 2025. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};