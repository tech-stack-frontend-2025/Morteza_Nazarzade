import React, { useState } from 'react';

export const ActivityGraph = () => {
  const [activeTab, setActiveTab] = useState('Days');
  
  const daysData = [
    { label: 'Mon', value: 75, height: '75%' },
    { label: 'Tue', value: 45, height: '45%' },
    { label: 'Wed', value: 90, height: '90%' },
    { label: 'Thu', value: 60, height: '60%' },
    { label: 'Fri', value: 85, height: '85%' },
    { label: 'Sat', value: 40, height: '40%' },
    { label: 'Sun', value: 70, height: '70%' }
  ];

  const tabs = ['Days', 'Months', 'Years'];

  return (
    <section className="py-16 px-4 bg-emerald-50">
      <div className="container mx-auto max-w-4xl">
        <h2 className="text-3xl md:text-4xl font-bold text-emerald-900 text-center mb-8">
          Your Weekly Activity
        </h2>
        
        {/* Tab Buttons */}
        <div className="flex justify-center mb-8">
          <div className="bg-white rounded-full p-1 shadow-lg">
            {tabs.map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-6 py-2 rounded-full font-medium transition-all duration-200 ${
                  activeTab === tab
                    ? 'bg-emerald-500 text-white shadow-md'
                    : 'text-emerald-700 hover:bg-emerald-100'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Bar Chart */}
        <div className="bg-white rounded-2xl p-8 shadow-lg">
          <div className="flex items-end justify-between h-64 space-x-4">
            {daysData.map((day, index) => (
              <div key={index} className="flex flex-col items-center flex-1">
                <div className="w-full max-w-12 relative">
                  <div
                    className="bg-gradient-to-t from-emerald-500 to-emerald-400 rounded-t-lg transition-all duration-700 hover:from-emerald-600 hover:to-emerald-500 cursor-pointer"
                    style={{ height: day.height }}
                  />
                  <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 text-sm font-medium text-emerald-700 opacity-0 hover:opacity-100 transition-opacity duration-200">
                    {day.value}%
                  </div>
                </div>
                <span className="mt-3 text-sm font-medium text-gray-600">{day.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};