import React from 'react';
import { Leaf, Menu, X } from 'lucide-react';
import { useState } from 'react';

export const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-emerald-800 text-white sticky top-0 z-50 shadow-lg">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <Leaf className="h-8 w-8 text-emerald-300" />
            <span className="text-2xl font-bold">Evergreen</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#home" className="hover:text-emerald-300 transition-colors duration-200 font-medium">
              Home
            </a>
            <a href="#programs" className="hover:text-emerald-300 transition-colors duration-200 font-medium">
              Programs
            </a>
            <a href="#about" className="hover:text-emerald-300 transition-colors duration-200 font-medium">
              About
            </a>
            <a href="#contact" className="hover:text-emerald-300 transition-colors duration-200 font-medium">
              Contact
            </a>
          </nav>

          {/* Login Button */}
          <div className="hidden md:block">
            <button className="bg-emerald-600 hover:bg-emerald-500 px-6 py-2 rounded-full font-medium transition-all duration-200 transform hover:scale-105">
              Log In
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-emerald-700">
            <nav className="flex flex-col space-y-3 pt-4">
              <a href="#home" className="hover:text-emerald-300 transition-colors duration-200 font-medium">
                Home
              </a>
              <a href="#programs" className="hover:text-emerald-300 transition-colors duration-200 font-medium">
                Programs
              </a>
              <a href="#about" className="hover:text-emerald-300 transition-colors duration-200 font-medium">
                About
              </a>
              <a href="#contact" className="hover:text-emerald-300 transition-colors duration-200 font-medium">
                Contact
              </a>
              <button className="bg-emerald-600 hover:bg-emerald-500 px-6 py-2 rounded-full font-medium transition-colors duration-200 mt-2 self-start">
                Log In
              </button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};