import React from 'react';
import { BookOpen, Headphones, Activity, Heart, Brain, Utensils, Moon, Users } from 'lucide-react';

export const ProgressOverview = () => {
  const progressCards = [
    {
      title: 'Wellness Learning',
      icon: BookOpen,
      modules: { remaining: 8, total: 12 },
      videos: { toWatch: 15, total: 20 },
      exercises: { toComplete: 6, total: 10 },
      progress: 65,
      bgColor: 'bg-emerald-100',
      borderColor: 'border-emerald-300',
      iconColor: 'text-emerald-600',
      progressColor: 'bg-emerald-500'
    },
    {
      title: 'Reading & Audio',
      icon: Headphones,
      modules: { remaining: 5, total: 8 },
      audios: { toListen: 12, total: 16 },
      practices: { toDo: 4, total: 6 },
      progress: 78,
      bgColor: 'bg-green-100',
      borderColor: 'border-green-300',
      iconColor: 'text-green-600',
      progressColor: 'bg-green-500'
    },
    {
      title: 'Physical Activity',
      icon: Activity,
      modules: { completed: 7, total: 10 },
      videos: { watched: 18, total: 22 },
      sessions: { done: 12, total: 15 },
      progress: 85,
      bgColor: 'bg-teal-100',
      borderColor: 'border-teal-300',
      iconColor: 'text-teal-600',
      progressColor: 'bg-teal-500'
    },
    {
      title: 'Mental Health',
      icon: Brain,
      modules: { completed: 4, total: 8 },
      sessions: { done: 10, total: 16 },
      exercises: { completed: 8, total: 12 },
      progress: 55,
      bgColor: 'bg-emerald-50',
      borderColor: 'border-emerald-200',
      iconColor: 'text-emerald-500',
      progressColor: 'bg-emerald-400'
    },
    {
      title: 'Nutrition',
      icon: Utensils,
      modules: { completed: 6, total: 9 },
      recipes: { tried: 15, total: 25 },
      plans: { followed: 3, total: 5 },
      progress: 72,
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200',
      iconColor: 'text-green-500',
      progressColor: 'bg-green-400'
    },
    {
      title: 'Sleep & Recovery',
      icon: Moon,
      modules: { completed: 3, total: 6 },
      nights: { tracked: 20, total: 30 },
      routines: { established: 2, total: 4 },
      progress: 68,
      bgColor: 'bg-teal-50',
      borderColor: 'border-teal-200',
      iconColor: 'text-teal-500',
      progressColor: 'bg-teal-400'
    },
    {
      title: 'Community',
      icon: Users,
      groups: { joined: 2, total: 5 },
      events: { attended: 8, total: 12 },
      connections: { made: 15, total: 20 },
      progress: 62,
      bgColor: 'bg-emerald-100',
      borderColor: 'border-emerald-300',
      iconColor: 'text-emerald-600',
      progressColor: 'bg-emerald-500'
    },
    {
      title: 'Mindfulness',
      icon: Heart,
      sessions: { completed: 25, total: 40 },
      minutes: { practiced: 450, total: 600 },
      streaks: { current: 7, best: 12 },
      progress: 75,
      bgColor: 'bg-green-100',
      borderColor: 'border-green-300',
      iconColor: 'text-green-600',
      progressColor: 'bg-green-500'
    }
  ];

  return (
    <section className="py-16 px-4 bg-white">
      <div className="container mx-auto max-w-7xl">
        <h2 className="text-3xl md:text-4xl font-bold text-emerald-900 text-center mb-4">
          Your Progress Overview
        </h2>
        <p className="text-emerald-700 text-center mb-12 max-w-2xl mx-auto">
          Drag to explore all your wellness activities and track your journey
        </p>
        
        {/* Scrollable Cards Container */}
        <div className="relative">
          <div className="flex overflow-x-auto scroll-smooth space-x-6 pb-4 px-2 scrollbar-thin scrollbar-thumb-emerald-300 scrollbar-track-emerald-100">
            {progressCards.map((card, index) => (
              <div
                key={index}
                className={`${card.bgColor} ${card.borderColor} border-2 rounded-2xl p-6 min-w-[320px] flex-shrink-0 transition-all duration-300 hover:transform hover:scale-105 hover:shadow-lg cursor-grab active:cursor-grabbing`}
              >
                <div className="flex items-center mb-6">
                  <card.icon className={`h-8 w-8 ${card.iconColor} mr-3`} />
                  <h3 className="text-xl font-semibold text-gray-800">{card.title}</h3>
                </div>
                
                <div className="space-y-4">
                  <div className="text-sm text-gray-600 space-y-1">
                    {card.modules && (
                      <p>Modules: {card.modules.remaining || card.modules.completed} of {card.modules.total}</p>
                    )}
                    {card.videos && (
                      <p>Videos: {card.videos.toWatch || card.videos.watched} of {card.videos.total}</p>
                    )}
                    {card.audios && (
                      <p>Audios: {card.audios.toListen} of {card.audios.total}</p>
                    )}
                    {card.exercises && (
                      <p>Exercises: {card.exercises.toComplete || card.exercises.completed} of {card.exercises.total}</p>
                    )}
                    {card.practices && (
                      <p>Practices: {card.practices.toDo} of {card.practices.total}</p>
                    )}
                    {card.sessions && (
                      <p>Sessions: {card.sessions.done || card.sessions.completed} of {card.sessions.total}</p>
                    )}
                    {card.recipes && (
                      <p>Recipes: {card.recipes.tried} of {card.recipes.total}</p>
                    )}
                    {card.plans && (
                      <p>Plans: {card.plans.followed} of {card.plans.total}</p>
                    )}
                    {card.nights && (
                      <p>Nights: {card.nights.tracked} of {card.nights.total}</p>
                    )}
                    {card.routines && (
                      <p>Routines: {card.routines.established} of {card.routines.total}</p>
                    )}
                    {card.groups && (
                      <p>Groups: {card.groups.joined} of {card.groups.total}</p>
                    )}
                    {card.events && (
                      <p>Events: {card.events.attended} of {card.events.total}</p>
                    )}
                    {card.connections && (
                      <p>Connections: {card.connections.made} of {card.connections.total}</p>
                    )}
                    {card.minutes && (
                      <p>Minutes: {card.minutes.practiced} of {card.minutes.total}</p>
                    )}
                    {card.streaks && (
                      <p>Current Streak: {card.streaks.current} days (Best: {card.streaks.best})</p>
                    )}
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-sm font-medium text-gray-700 mb-2">
                      <span>Progress</span>
                      <span>{card.progress}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div
                        className={`${card.progressColor} h-3 rounded-full transition-all duration-700 ease-out`}
                        style={{ width: `${card.progress}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Scroll Indicators */}
          <div className="flex justify-center mt-6 space-x-2">
            {Array.from({ length: Math.ceil(progressCards.length / 3) }).map((_, index) => (
              <div
                key={index}
                className="w-2 h-2 rounded-full bg-emerald-300 opacity-50"
              />
            ))}
          </div>
        </div>
        
        {/* Helper Text */}
        <div className="text-center mt-8">
          <p className="text-sm text-emerald-600 font-medium">
            ← Drag to explore more activities →
          </p>
        </div>
      </div>
    </section>
  );
};