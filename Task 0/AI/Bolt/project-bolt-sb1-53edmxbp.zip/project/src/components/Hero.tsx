import React from 'react';

export const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-50 via-green-50 to-emerald-100" />
      
      {/* Nature-inspired background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-32 h-32 bg-emerald-300 rounded-full blur-2xl" />
        <div className="absolute top-40 right-20 w-24 h-24 bg-green-400 rounded-full blur-xl" />
        <div className="absolute bottom-20 left-1/4 w-40 h-40 bg-emerald-200 rounded-full blur-3xl" />
        <div className="absolute bottom-40 right-10 w-28 h-28 bg-green-300 rounded-full blur-xl" />
      </div>

      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <h1 className="text-5xl md:text-7xl font-bold text-emerald-900 mb-6 leading-tight">
          Grow Your Wellness with{' '}
          <span className="text-emerald-600">Evergreen</span>
        </h1>
        
        <p className="text-xl md:text-2xl text-emerald-700 mb-8 max-w-2xl mx-auto leading-relaxed">
          Your personal space for health, mindfulness, and growth.
        </p>
        
        <button className="bg-emerald-500 hover:bg-emerald-600 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105 hover:shadow-lg">
          Join Now
        </button>
      </div>

      {/* Decorative elements */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent" />
    </section>
  );
};