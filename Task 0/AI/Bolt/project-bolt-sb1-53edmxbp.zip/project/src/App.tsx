import React from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ProgressOverview } from './components/ProgressOverview';
import { ActivityGraph } from './components/ActivityGraph';
import { ProfileCalendar } from './components/ProfileCalendar';
import { Footer } from './components/Footer';

function App() {
  return (
    <div className="font-sans">
      <Header />
      <main>
        <Hero />
        <ProgressOverview />
        <ActivityGraph />
        <ProfileCalendar />
      </main>
      <Footer />
    </div>
  );
}

export default App;