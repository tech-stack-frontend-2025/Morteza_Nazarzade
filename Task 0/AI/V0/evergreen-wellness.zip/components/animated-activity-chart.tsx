"use client"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const activityData = [
  { day: "Mon", height: 40, color: "bg-green-400 dark:bg-green-500", label: "Monday" },
  { day: "Tue", height: 60, color: "bg-green-500 dark:bg-green-400", label: "Tuesday" },
  { day: "Wed", height: 50, color: "bg-green-400 dark:bg-green-500", label: "Wednesday" },
  { day: "Thu", height: 80, color: "bg-green-300 dark:bg-green-600", label: "Thursday" },
  { day: "Fri", height: 100, color: "bg-green-500 dark:bg-green-400", label: "Friday" },
  { day: "Sat", height: 110, color: "bg-green-400 dark:bg-green-500", label: "Saturday" },
  { day: "Sun", height: 90, color: "bg-green-300 dark:bg-green-600", label: "Sunday" },
]

export default function AnimatedActivityChart() {
  const [isVisible, setIsVisible] = useState(false)
  const [animatedHeights, setAnimatedHeights] = useState<{ [key: number]: number }>({})
  const chartRef = useRef<HTMLDivElement>(null)

  // Intersection Observer for chart animation
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio > 0.3) {
            setIsVisible(true)
          }
        })
      },
      {
        threshold: [0.3],
        rootMargin: "-100px",
      },
    )

    if (chartRef.current) {
      observer.observe(chartRef.current)
    }

    return () => observer.disconnect()
  }, [])

  // Animate bars when chart becomes visible
  useEffect(() => {
    if (isVisible) {
      activityData.forEach((bar, index) => {
        setTimeout(() => {
          let currentHeight = 0
          const targetHeight = bar.height
          const increment = targetHeight / 60 // 60 frames for 1 second animation

          const animateBar = () => {
            currentHeight += increment

            if (currentHeight >= targetHeight) {
              setAnimatedHeights((prev) => ({ ...prev, [index]: targetHeight }))
            } else {
              setAnimatedHeights((prev) => ({ ...prev, [index]: Math.round(currentHeight) }))
              requestAnimationFrame(animateBar)
            }
          }

          requestAnimationFrame(animateBar)
        }, index * 150) // Stagger animations by 150ms
      })
    }
  }, [isVisible])

  return (
    <div ref={chartRef}>
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-3xl font-bold text-green-800 dark:text-green-200 transition-colors duration-300">
          Your Weekly Activity
        </h2>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            className="rounded-full bg-transparent border-green-600 dark:border-green-400 text-green-700 dark:text-green-300 hover:bg-green-50 dark:hover:bg-green-900 transition-colors duration-300"
          >
            Days
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="rounded-full text-green-600 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900 transition-colors duration-300"
          >
            Months
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="rounded-full text-green-600 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-900 transition-colors duration-300"
          >
            Years
          </Button>
        </div>
      </div>

      <Card className="rounded-2xl border-0 bg-green-800 dark:bg-green-900 text-white overflow-hidden transition-colors duration-300">
        <CardContent className="p-8">
          <div className="flex items-end justify-between h-48 space-x-4">
            {activityData.map((bar, index) => {
              const animatedHeight = animatedHeights[index] || 0
              const heightPercentage = (animatedHeight / 110) * 100 // 110 is max height

              return (
                <div key={index} className="flex flex-col items-center flex-1 group">
                  <div className="relative w-full mb-2 flex items-end justify-center h-44">
                    {/* Background bar (for reference) */}
                    <div className="absolute bottom-0 w-full h-1 bg-white/10 dark:bg-white/20 rounded-t-lg transition-colors duration-300" />

                    {/* Animated bar */}
                    <div
                      className={`relative w-full ${bar.color} rounded-t-lg transition-all duration-1000 ease-out transform hover:scale-105 cursor-pointer shadow-lg`}
                      style={{
                        height: `${heightPercentage}%`,
                        minHeight: animatedHeight > 0 ? "8px" : "0px",
                      }}
                    >
                      {/* Glow effect */}
                      {isVisible && animatedHeight > 0 && (
                        <div
                          className="absolute inset-0 bg-gradient-to-t from-white/20 dark:from-white/30 to-transparent rounded-t-lg transition-colors duration-300"
                          style={{
                            animation: `barGlow 2s ease-out ${index * 0.15}s`,
                          }}
                        />
                      )}

                      {/* Shimmer effect */}
                      {isVisible && animatedHeight > 0 && (
                        <div
                          className="absolute inset-0 bg-gradient-to-t from-transparent via-white/30 dark:via-white/40 to-transparent rounded-t-lg opacity-0 transition-colors duration-300"
                          style={{
                            animation: `barShimmer 1.5s ease-out ${index * 0.15 + 0.5}s`,
                          }}
                        />
                      )}
                    </div>

                    {/* Activity value tooltip */}
                    <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-white/90 dark:bg-green-800/90 text-green-800 dark:text-green-200 px-2 py-1 rounded text-xs font-semibold opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none">
                      {animatedHeight}%
                    </div>
                  </div>

                  <span className="text-sm font-medium transition-colors duration-200 group-hover:text-green-200 dark:group-hover:text-green-300">
                    {bar.day}
                  </span>
                </div>
              )
            })}
          </div>

          {/* Activity summary */}
          {isVisible && (
            <div className="mt-6 pt-4 border-t border-white/20 dark:border-white/30 transition-colors duration-300">
              <div className="flex justify-between items-center text-sm">
                <span className="text-green-200 dark:text-green-300 transition-colors duration-300">
                  Weekly Average
                </span>
                <span className="font-semibold">
                  {Math.round(activityData.reduce((sum, bar) => sum + bar.height, 0) / activityData.length)}%
                </span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
