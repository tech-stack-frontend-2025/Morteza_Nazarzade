"use client"

import { useState, useEffect } from "react"
import Image from "next/image"

const backgroundImages = [
  {
    src: "/hero-bg-1.png",
    alt: "Peaceful forest with morning light",
    query: "peaceful forest with golden morning sunlight filtering through trees, serene nature landscape",
  },
  {
    src: "/hero-bg-2.png",
    alt: "Mountain lake reflection",
    query: "calm mountain lake with perfect reflection, misty morning, wellness and tranquility",
  },
  {
    src: "/hero-bg-3.png",
    alt: "Zen garden with stones",
    query: "zen garden with balanced stones, bamboo, peaceful meditation space, wellness concept",
  },
  {
    src: "/hero-bg-4.png",
    alt: "Green meadow with flowers",
    query: "lush green meadow with wildflowers, soft natural lighting, wellness and growth concept",
  },
]

const slideDirections = [
  "translate-x-full", // slide from right
  "translate-y-full", // slide from bottom
  "-translate-x-full", // slide from left
  "-translate-y-full", // slide from top
]

export default function HeroBackground() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [nextImageIndex, setNextImageIndex] = useState(1)
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [slideDirection, setSlideDirection] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setIsTransitioning(true)

      // Set random slide direction for variety
      setSlideDirection(Math.floor(Math.random() * slideDirections.length))

      setTimeout(() => {
        setCurrentImageIndex(nextImageIndex)
        setNextImageIndex((nextImageIndex + 1) % backgroundImages.length)
        setIsTransitioning(false)
      }, 1500) // Duration of the cover transition
    }, 10000) // Change every 10 seconds

    return () => clearInterval(interval)
  }, [nextImageIndex])

  return (
    <div className="absolute inset-0 overflow-hidden">
      {/* Current Image */}
      <div className="absolute inset-0">
        <Image
          src={backgroundImages[currentImageIndex].src || "/placeholder.svg"}
          alt={backgroundImages[currentImageIndex].alt}
          fill
          className="object-cover"
          priority
        />
      </div>

      {/* Next Image (slides in with cover effect from random direction) */}
      <div
        className={`absolute inset-0 transition-transform duration-1500 ease-in-out ${
          isTransitioning ? "translate-x-0 translate-y-0" : slideDirections[slideDirection]
        }`}
        style={{
          zIndex: 1,
        }}
      >
        <Image
          src={backgroundImages[nextImageIndex].src || "/placeholder.svg"}
          alt={backgroundImages[nextImageIndex].alt}
          fill
          className="object-cover"
        />

        {/* Subtle slide-in animation overlay */}
        <div
          className={`absolute inset-0 bg-gradient-to-br from-white/10 to-transparent transition-opacity duration-1500 ${
            isTransitioning ? "opacity-0" : "opacity-100"
          }`}
        />
      </div>

      {/* Overlay for text readability - darker in dark mode */}
      <div
        className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/20 to-black/40 dark:from-black/50 dark:via-black/40 dark:to-black/60 transition-colors duration-300"
        style={{ zIndex: 2 }}
      />
    </div>
  )
}
