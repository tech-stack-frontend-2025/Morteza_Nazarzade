"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { BookOpen, Dumbbell, Headphones, Heart, Brain, Leaf, Moon, Utensils } from "lucide-react"

const progressData = [
  {
    title: "Wellness Learning",
    icon: BookOpen,
    color: "bg-green-700 hover:bg-green-600 dark:bg-green-800 dark:hover:bg-green-700",
    progress: 55,
    details: ["6 modules remaining to complete", "4 videos to watch", "2 practical exercises to do"],
  },
  {
    title: "Reading & Audio",
    icon: Headphones,
    color: "bg-green-600 hover:bg-green-500 dark:bg-green-700 dark:hover:bg-green-600",
    progress: 85,
    details: ["4 modules remaining to complete", "3 audio modules to listen", "1 practical exercise to do"],
  },
  {
    title: "Physical Activity",
    icon: Dumbbell,
    color: "bg-green-500 hover:bg-green-400 dark:bg-green-600 dark:hover:bg-green-500",
    progress: 100,
    details: ["4 modules completed", "10 videos watched"],
  },
  {
    title: "Mindfulness",
    icon: Brain,
    color: "bg-green-600 hover:bg-green-500 dark:bg-green-700 dark:hover:bg-green-600",
    progress: 72,
    details: ["8 meditation sessions completed", "3 breathing exercises to try", "2 mindfulness practices remaining"],
  },
  {
    title: "Nutrition",
    icon: Utensils,
    color: "bg-green-700 hover:bg-green-600 dark:bg-green-800 dark:hover:bg-green-700",
    progress: 43,
    details: ["5 meal plans to explore", "3 nutrition guides to read", "4 healthy recipes to try"],
  },
  {
    title: "Sleep & Recovery",
    icon: Moon,
    color: "bg-green-500 hover:bg-green-400 dark:bg-green-600 dark:hover:bg-green-500",
    progress: 68,
    details: ["6 sleep hygiene tips learned", "2 recovery techniques to practice", "3 relaxation exercises remaining"],
  },
  {
    title: "Mental Health",
    icon: Heart,
    color: "bg-green-600 hover:bg-green-500 dark:bg-green-700 dark:hover:bg-green-600",
    progress: 91,
    details: [
      "7 emotional wellness modules completed",
      "1 stress management technique to learn",
      "2 self-care practices to implement",
    ],
  },
  {
    title: "Nature Connection",
    icon: Leaf,
    color: "bg-green-700 hover:bg-green-600 dark:bg-green-800 dark:hover:bg-green-700",
    progress: 34,
    details: [
      "4 outdoor activities to try",
      "6 nature-based exercises remaining",
      "3 eco-wellness practices to explore",
    ],
  },
]

export default function ProgressSlider() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isDragging, setIsDragging] = useState(false)
  const [startX, setStartX] = useState(0)
  const [scrollLeft, setScrollLeft] = useState(0)
  const sliderRef = useRef<HTMLDivElement>(null)
  const [cardWidth, setCardWidth] = useState(0)

  const [animatedProgress, setAnimatedProgress] = useState<{ [key: number]: number }>({})
  const [visibleCards, setVisibleCards] = useState<Set<number>>(new Set())
  const cardRefs = useRef<(HTMLDivElement | null)[]>([])

  // Intersection Observer for progress animation
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const cardIndex = Number.parseInt(entry.target.getAttribute("data-card-index") || "0")

          if (entry.isIntersecting && entry.intersectionRatio > 0.3) {
            setVisibleCards((prev) => new Set([...prev, cardIndex]))
          }
        })
      },
      {
        threshold: [0.3, 0.7],
        rootMargin: "-50px",
      },
    )

    cardRefs.current.forEach((card) => {
      if (card) observer.observe(card)
    })

    return () => observer.disconnect()
  }, [])

  // Animate progress bars when cards become visible
  useEffect(() => {
    visibleCards.forEach((cardIndex) => {
      if (animatedProgress[cardIndex] === undefined) {
        const targetProgress = progressData[cardIndex].progress
        let currentProgress = 0

        const animateProgress = () => {
          const increment = targetProgress / 90 // 60 frames for 1 second animation
          currentProgress += increment

          if (currentProgress >= targetProgress) {
            setAnimatedProgress((prev) => ({ ...prev, [cardIndex]: targetProgress }))
          } else {
            setAnimatedProgress((prev) => ({ ...prev, [cardIndex]: Math.round(currentProgress) }))
            requestAnimationFrame(animateProgress)
          }
        }

        // Delay animation slightly for better effect
        setTimeout(() => {
          requestAnimationFrame(animateProgress)
        }, cardIndex * 150) // Stagger animations
      }
    })
  }, [visibleCards, animatedProgress])

  useEffect(() => {
    const updateCardWidth = () => {
      if (sliderRef.current) {
        const containerWidth = sliderRef.current.offsetWidth
        // Show 1 card on mobile, 2 on tablet, 3 on desktop
        if (containerWidth < 768) {
          setCardWidth(containerWidth - 32) // Full width minus padding
        } else if (containerWidth < 1024) {
          setCardWidth((containerWidth - 48) / 2) // Half width minus gap
        } else {
          setCardWidth((containerWidth - 64) / 3) // Third width minus gap
        }
      }
    }

    updateCardWidth()
    window.addEventListener("resize", updateCardWidth)
    return () => window.removeEventListener("resize", updateCardWidth)
  }, [])

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true)
    setStartX(e.pageX - (sliderRef.current?.offsetLeft || 0))
    setScrollLeft(sliderRef.current?.scrollLeft || 0)
  }

  const handleTouchStart = (e: React.TouchEvent) => {
    setIsDragging(true)
    setStartX(e.touches[0].pageX - (sliderRef.current?.offsetLeft || 0))
    setScrollLeft(sliderRef.current?.scrollLeft || 0)
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return
    e.preventDefault()
    const x = e.pageX - (sliderRef.current?.offsetLeft || 0)
    const walk = (x - startX) * 2
    if (sliderRef.current) {
      sliderRef.current.scrollLeft = scrollLeft - walk
    }
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging) return
    const x = e.touches[0].pageX - (sliderRef.current?.offsetLeft || 0)
    const walk = (x - startX) * 2
    if (sliderRef.current) {
      sliderRef.current.scrollLeft = scrollLeft - walk
    }
  }

  const handleMouseUp = () => {
    setIsDragging(false)
    snapToCard()
  }

  const handleTouchEnd = () => {
    setIsDragging(false)
    snapToCard()
  }

  const snapToCard = () => {
    if (sliderRef.current && cardWidth > 0) {
      const scrollLeft = sliderRef.current.scrollLeft
      const newIndex = Math.round(scrollLeft / (cardWidth + 16)) // 16 is gap
      setCurrentIndex(Math.max(0, Math.min(newIndex, progressData.length - 1)))

      sliderRef.current.scrollTo({
        left: newIndex * (cardWidth + 16),
        behavior: "smooth",
      })
    }
  }

  const goToSlide = (index: number) => {
    setCurrentIndex(index)
    if (sliderRef.current && cardWidth > 0) {
      sliderRef.current.scrollTo({
        left: index * (cardWidth + 16),
        behavior: "smooth",
      })
    }
  }

  return (
    <div className="relative max-w-6xl mx-auto">
      {/* Slider Container */}
      <div
        ref={sliderRef}
        className={`flex gap-4 overflow-x-auto scrollbar-hide pb-4 ${isDragging ? "cursor-grabbing" : "cursor-grab"}`}
        style={{
          scrollbarWidth: "none",
          msOverflowStyle: "none",
          scrollSnapType: "x mandatory",
        }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {progressData.map((item, index) => {
          const IconComponent = item.icon
          const displayProgress = animatedProgress[index] ?? 0

          return (
            <Card
              key={index}
              ref={(el) => (cardRefs.current[index] = el)}
              data-card-index={index}
              className={`${item.color} text-white rounded-2xl border-0 transition-all duration-300 flex-shrink-0 select-none transform hover:scale-105`}
              style={{
                width: cardWidth || "auto",
                minWidth: "280px",
                scrollSnapAlign: "start",
              }}
            >
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{item.title}</CardTitle>
                  <IconComponent className="w-6 h-6" />
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2 text-sm">
                  {item.details.map((detail, detailIndex) => (
                    <div key={detailIndex}>• {detail}</div>
                  ))}
                </div>
                <div className="pt-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm">Progress</span>
                    <span className="text-sm font-bold transition-all duration-300">{displayProgress}%</span>
                  </div>
                  <div className="relative overflow-hidden">
                    <Progress
                      value={displayProgress}
                      className="h-3 bg-black/30 dark:bg-black/50 transition-all duration-500"
                    />
                    {visibleCards.has(index) && displayProgress > 0 && (
                      <>
                        {/* Animated fill overlay */}
                        <div
                          className="absolute top-0 left-0 h-3 bg-gradient-to-r from-white via-white/95 to-white/85 dark:from-white dark:via-white/90 dark:to-white/80 rounded-full transition-all duration-1500 ease-out shadow-sm"
                          style={{
                            width: `${displayProgress}%`,
                            boxShadow: "0 0 10px rgba(255, 255, 255, 0.4)",
                          }}
                        />
                        {/* Shimmer effect */}
                        <div
                          className="absolute top-0 left-0 h-3 bg-gradient-to-r from-transparent via-white to-transparent rounded-full opacity-80"
                          style={{
                            width: "40%",
                            animation: `shimmer 3s ease-in-out infinite ${index * 0.2}s`,
                            transform: `translateX(-100%)`,
                          }}
                        />
                      </>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Dots Indicator */}
      <div className="flex justify-center space-x-2 mt-6">
        {progressData.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentIndex
                ? "bg-green-600 dark:bg-green-400 scale-110"
                : "bg-green-200 dark:bg-green-700 hover:bg-green-400 dark:hover:bg-green-500"
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>

      {/* Navigation Arrows */}
      <button
        onClick={() => goToSlide(Math.max(0, currentIndex - 1))}
        disabled={currentIndex === 0}
        className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 w-10 h-10 bg-white dark:bg-green-800 rounded-full shadow-lg flex items-center justify-center text-green-600 dark:text-green-300 hover:bg-green-50 dark:hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
        aria-label="Previous slide"
      >
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
      </button>

      <button
        onClick={() => goToSlide(Math.min(progressData.length - 1, currentIndex + 1))}
        disabled={currentIndex === progressData.length - 1}
        className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 w-10 h-10 bg-white dark:bg-green-800 rounded-full shadow-lg flex items-center justify-center text-green-600 dark:text-green-300 hover:bg-green-50 dark:hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
        aria-label="Next slide"
      >
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
        </svg>
      </button>
    </div>
  )
}
