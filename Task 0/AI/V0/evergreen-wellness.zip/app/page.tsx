import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { LogIn, Menu, Play, MoreHorizontal } from "lucide-react"
import ProgressSlider from "@/components/progress-slider"
import HeroBackground from "@/components/hero-background"
import AnimatedActivityChart from "@/components/animated-activity-chart"
import { ThemeToggle } from "@/components/theme-toggle"

export default function EvergreenLanding() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-green-100 dark:from-slate-900 dark:to-green-950 transition-colors duration-500">
      {/* Header */}
      <header className="bg-green-800 dark:bg-slate-900 text-white px-4 py-4 relative z-10 transition-colors duration-500 border-b border-green-700 dark:border-slate-800">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-green-600 dark:bg-green-500 rounded-full flex items-center justify-center transition-colors duration-300 shadow-lg">
              <span className="text-sm font-bold">E</span>
            </div>
            <span className="text-xl font-bold">Evergreen</span>
          </div>

          <nav className="hidden md:flex items-center space-x-8">
            <a href="#" className="hover:text-green-200 dark:hover:text-green-300 transition-colors duration-200">
              Home
            </a>
            <a href="#" className="hover:text-green-200 dark:hover:text-green-300 transition-colors duration-200">
              Programs
            </a>
            <a href="#" className="hover:text-green-200 dark:hover:text-green-300 transition-colors duration-200">
              About
            </a>
            <a href="#" className="hover:text-green-200 dark:hover:text-green-300 transition-colors duration-200">
              Contact
            </a>
          </nav>

          <div className="flex items-center space-x-4">
            <ThemeToggle />
            <Button
              variant="ghost"
              size="sm"
              className="text-white hover:bg-green-700 dark:hover:bg-slate-800 transition-colors duration-200"
            >
              <LogIn className="w-4 h-4 mr-2" />
              Log In
            </Button>
            <Button variant="ghost" size="sm" className="md:hidden">
              <Menu className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section with Background Slideshow */}
      <section className="relative py-20 px-4 text-center min-h-[600px] flex items-center justify-center overflow-hidden">
        <HeroBackground />

        <div className="container mx-auto max-w-4xl relative z-10">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 drop-shadow-2xl animate-in fade-in duration-1000">
            Grow Your Wellness with Evergreen
          </h1>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto drop-shadow-lg animate-in fade-in duration-1000 delay-300">
            Your personal space for health, mindfulness, and growth.
          </p>
          <Button
            size="lg"
            className="bg-green-600 hover:bg-green-700 dark:bg-green-500 dark:hover:bg-green-600 text-white px-8 py-3 rounded-full text-lg shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 animate-in fade-in duration-1000 delay-500"
          >
            Join Now
          </Button>
        </div>

        {/* Enhanced slide indicators with progress */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-3 z-10">
          {[0, 1, 2, 3].map((index) => (
            <div
              key={index}
              className="relative w-3 h-3 rounded-full bg-white/40 dark:bg-white/60 transition-all duration-300 shadow-sm"
            >
              {/* Active indicator with animated progress */}
              <div className="absolute inset-0 rounded-full bg-white/80 dark:bg-white/90 scale-0 animate-pulse" />
            </div>
          ))}
        </div>

        {/* Slide direction indicator (optional visual element) */}
        <div className="absolute top-8 right-8 z-10 opacity-30">
          <div className="w-8 h-8 border-2 border-white rounded-full flex items-center justify-center">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
          </div>
        </div>
      </section>

      {/* Progress Overview Section - Draggable Slider */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-green-800 dark:text-green-100 mb-8 text-center transition-colors duration-300">
            Your Progress
          </h2>
          <ProgressSlider />
        </div>
      </section>

      {/* Activity Graph Section with Animations */}
      <section className="py-16 px-4 bg-white dark:bg-slate-900 transition-colors duration-500 border-y border-green-100 dark:border-slate-800">
        <div className="container mx-auto max-w-4xl">
          <AnimatedActivityChart />
        </div>
      </section>

      {/* Profile & Calendar Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Profile Section */}
            <div className="space-y-6">
              <h2 className="text-3xl font-bold text-green-800 dark:text-green-100 transition-colors duration-300">
                My Profile
              </h2>

              <Card className="rounded-2xl border-0 bg-white dark:bg-slate-800 shadow-xl dark:shadow-2xl transition-all duration-300 hover:shadow-2xl dark:hover:shadow-green-900/20">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-green-800 dark:text-green-100 transition-colors duration-300">
                      Profile
                    </h3>
                    <Badge
                      variant="outline"
                      className="rounded-full border-green-600 dark:border-green-400 text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-900/30 transition-colors duration-300"
                    >
                      Intermediate
                    </Badge>
                  </div>

                  <Image
                    src="/peaceful-meditation.png"
                    alt="Peaceful nature scene"
                    width={400}
                    height={200}
                    className="w-full h-48 object-cover rounded-xl mb-4 shadow-lg"
                  />

                  <div className="bg-green-700 dark:bg-green-800 text-white p-4 rounded-xl transition-colors duration-300 shadow-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold">Audio Course - Introspection</h4>
                        <p className="text-sm text-green-200 dark:text-green-300">Media Option - 15 min</p>
                      </div>
                      <Play className="w-6 h-6 hover:scale-110 transition-transform duration-200 cursor-pointer" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Daily Quote */}
              <Card className="rounded-2xl border-0 bg-green-50 dark:bg-slate-800/50 transition-all duration-300 shadow-lg hover:shadow-xl">
                <CardContent className="p-6">
                  <h4 className="font-semibold text-green-800 dark:text-green-100 mb-2 transition-colors duration-300">
                    Daily Quote
                  </h4>
                  <p className="text-green-700 dark:text-green-200 italic transition-colors duration-300">
                    "Well-being begins with an intention: choose yourself, every day."
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Calendar Section */}
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-3xl font-bold text-green-800 dark:text-green-100 transition-colors duration-300">
                  Calendar
                </h2>
                <Badge
                  variant="outline"
                  className="rounded-full border-green-600 dark:border-green-400 text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-900/30 transition-colors duration-300"
                >
                  September
                </Badge>
              </div>

              <Card className="rounded-2xl border-0 bg-white dark:bg-slate-800 shadow-xl dark:shadow-2xl transition-all duration-300 hover:shadow-2xl dark:hover:shadow-green-900/20">
                <CardContent className="p-6">
                  {/* Calendar Grid */}
                  <div className="grid grid-cols-7 gap-2 mb-6 text-center text-sm">
                    {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day) => (
                      <div
                        key={day}
                        className="font-semibold text-green-700 dark:text-green-300 p-2 transition-colors duration-300"
                      >
                        {day}
                      </div>
                    ))}
                    {[13, 14, 15, 16, 17, 18, 19].map((date) => (
                      <div
                        key={date}
                        className="p-2 text-green-600 dark:text-green-400 transition-colors duration-300 hover:bg-green-50 dark:hover:bg-green-900/30 rounded-lg cursor-pointer"
                      >
                        {date}
                      </div>
                    ))}
                  </div>

                  {/* Upcoming Activities */}
                  <div className="space-y-3">
                    <div className="bg-green-100 dark:bg-green-900/40 p-4 rounded-xl transition-all duration-300 hover:bg-green-200 dark:hover:bg-green-900/60 cursor-pointer">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-semibold text-green-800 dark:text-green-100 transition-colors duration-300">
                            Meditation & Breathing
                          </h4>
                          <p className="text-sm text-green-600 dark:text-green-300 transition-colors duration-300">
                            05:00 - 06:00 a.m
                          </p>
                        </div>
                        <MoreHorizontal className="w-5 h-5 text-green-600 dark:text-green-400 transition-colors duration-300" />
                      </div>
                    </div>

                    <div className="bg-green-100 dark:bg-green-900/40 p-4 rounded-xl transition-all duration-300 hover:bg-green-200 dark:hover:bg-green-900/60 cursor-pointer">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-semibold text-green-800 dark:text-green-100 transition-colors duration-300">
                            Audio Reading
                          </h4>
                          <p className="text-sm text-green-600 dark:text-green-300 transition-colors duration-300">
                            15:00 - 17:00 p.m
                          </p>
                        </div>
                        <MoreHorizontal className="w-5 h-5 text-green-600 dark:text-green-400 transition-colors duration-300" />
                      </div>
                    </div>

                    <div className="bg-green-100 dark:bg-green-900/40 p-4 rounded-xl transition-all duration-300 hover:bg-green-200 dark:hover:bg-green-900/60 cursor-pointer">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-semibold text-green-800 dark:text-green-100 transition-colors duration-300">
                            Workout Session
                          </h4>
                          <p className="text-sm text-green-600 dark:text-green-300 transition-colors duration-300">
                            19:00 - 20:00 p.m
                          </p>
                        </div>
                        <MoreHorizontal className="w-5 h-5 text-green-600 dark:text-green-400 transition-colors duration-300" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-green-800 dark:bg-slate-900 text-white py-12 px-4 transition-colors duration-500 border-t border-green-700 dark:border-slate-800">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-green-600 dark:bg-green-500 rounded-full flex items-center justify-center transition-colors duration-300 shadow-lg">
                  <span className="text-sm font-bold">E</span>
                </div>
                <span className="text-xl font-bold">Evergreen</span>
              </div>
              <p className="text-green-200 dark:text-green-300 transition-colors duration-300">
                Your personal space for health, mindfulness, and growth.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-green-200 dark:text-green-300 transition-colors duration-300">
                <li>
                  <a href="#" className="hover:text-white transition-colors duration-200">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors duration-200">
                    Programs
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors duration-200">
                    Contact
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors duration-200">
                    Privacy Policy
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Programs</h4>
              <ul className="space-y-2 text-green-200 dark:text-green-300 transition-colors duration-300">
                <li>
                  <a href="#" className="hover:text-white transition-colors duration-200">
                    Wellness Learning
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors duration-200">
                    Reading & Audio
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors duration-200">
                    Physical Activity
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors duration-200">
                    Meditation
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Follow Us</h4>
              <div className="flex space-x-4">
                <div className="w-8 h-8 bg-green-600 dark:bg-green-500 rounded-full flex items-center justify-center hover:bg-green-500 dark:hover:bg-green-400 transition-all duration-200 cursor-pointer transform hover:scale-110 shadow-lg">
                  <span className="text-xs">f</span>
                </div>
                <div className="w-8 h-8 bg-green-600 dark:bg-green-500 rounded-full flex items-center justify-center hover:bg-green-500 dark:hover:bg-green-400 transition-all duration-200 cursor-pointer transform hover:scale-110 shadow-lg">
                  <span className="text-xs">t</span>
                </div>
                <div className="w-8 h-8 bg-green-600 dark:bg-green-500 rounded-full flex items-center justify-center hover:bg-green-500 dark:hover:bg-green-400 transition-all duration-200 cursor-pointer transform hover:scale-110 shadow-lg">
                  <span className="text-xs">i</span>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-green-700 dark:border-slate-700 pt-8 text-center text-green-200 dark:text-green-300 transition-colors duration-300">
            <p>© Evergreen 2025. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
